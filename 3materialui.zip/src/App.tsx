import './App.css';
import { LessonButton } from './components/LessonButton';
import { LessonTypography } from './components/LessonTypography';

function App() {
  return (
    <div className="App">
      {/* <LessonTypography/> */}
      <LessonButton />
    </div>
  );
}

export default App;
